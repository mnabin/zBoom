﻿<?php get_header();

/*Template Name: Contact Form*/
?>

<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-2-3">
				<div class="wrap-col">
					<article>
					<?php while(have_posts()) : the_post();?>
						<div class="comment">
							<?php the_content();?>
						</div>
						<?php endwhile;?>
					</article>
				</div>
			</div>
			<div class="col-1-3">
				
				<?php dynamic_sidebar('contact-sidebar');?>
				
				
			</div>
		</div>
	</div>
</section>
<!--------------Footer--------------->
<?php get_footer();?>