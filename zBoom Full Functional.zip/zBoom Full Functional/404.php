﻿<?php get_header();?>
<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-2-3">
				<div class="wrap-col">
				<article>
				<h2>404 PAGE NOT FOUND</h2>
				<p>Sorry! May be you are looking for something else. Please visit our <a href="<?php bloginfo('home');?>">Homepage.</a></p>
				
					</article>
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					
					
					<div class="box">
						<?php dynamic_sidebar('right-sidebar');?>
					</div>
					
					
					
					
					
					
				</div>
			</div>
		</div>
	</div>
</section>
<!--------------Footer--------------->
<?php get_footer();?>