﻿<?php get_header();
/*Template Name: Gallery*/
?>
<!--------------Content--------------->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			
			<?php 
				$gallerypost = new WP_Query(array(
					'post_type' => 'gallery_items',
					'posts_per_page' => 12
				));
			?>
			
			<?php while ($gallerypost->have_posts()) : $gallerypost->the_post();?>
			<div class="col-1-4">
				<div class="wrap-col">
					<article>
						<a href="<?php the_permalink();?>"><?php the_post_thumbnail();?></a>
						<h2><?php the_title();?></h2>
					</article>
				</div>
			</div>
			<?php endwhile;?>
			
		
		</div>
	</div>
</section>
<!--------------Footer--------------->
<?php get_footer();?>