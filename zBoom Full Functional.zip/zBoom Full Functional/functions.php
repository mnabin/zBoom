<?php 

function zboom_default_functions(){
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('custom-background');
	
	load_theme_textdomain('zboom',get_template_directory_uri().'/languages');
	
	if (function_exists(register_nav_menu))	
		register_nav_menu('main-menu',__('Main Menu', 'zboom'));
	
	function read_more($limit){
		$post_content = explode (" ",get_the_content());
		$less_content = array_slice($post_content,0,$limit);
		echo implode (" ", $less_content);
	}

	register_post_type('zboom_slider',array(
		'labels'	=> array(
			'name'	=> 'zBoom Slider',
			'add_new_item' => 'Add new slider photo'),
		'public'	=> true,
		'supports'	=> array('title','thumbnail','editor'),
		'menu-position'	=> 7
	));	
	
	register_post_type('zboom_slider',array(
		'labels'	=> array(
			'name'	=> 'zBoom Slider',
			'add_new_item' => 'Add new slider photo'),
		'public'	=> true,
		'supports'	=> array('title','thumbnail','editor'),
		'menu-position'	=> 6
	));	
		
	register_post_type('frontpage_blocks',array(
		'labels' => array(
			'name' => 'Frontpage Block Posts',
			'add_new_item' => 'Add YOur Service Descriptions'
														),
		'supports'	=> array('title','thumbnail','editor'),											
		'public' => true,
		'menu-position' => 7
	));

	register_post_type('featured_post',array(
		'labels'	=> array(
			'name' => 'Featured Posts',
			'add_new_item' => 'Add Your Featured Posts here' 
																),
		'supports' => array('title','thumbnail','editor'),
		'public'=> true,
		'menu-position' => 8
		
	));

	register_post_type('gallery_items',array(
		'labels'	=> array(
				'name'	=> 'Gallaery Posts',
				'add_new_item' => 'Add your Gallaery Items' ),
		'public'    => true,
		'supports'  => array('title','thumbnail','editor'),
		'menu-position' => 9
	));
	
	
	
	
	
	
	

	
		
		
}
add_action("after_setup_theme","zboom_default_functions");


	function zboom_right_sidebar(){
		register_sidebar(array(
			'id' 	=> 'right-sidebar',
			'name'  => 'zBoom Theme Right Sidebar',
			'description' => 'You can add several options in your right sidebar.',
			'before_widget' => '<div class="box">',
			'after_widget'  => '</div></div>',
			'before_title'  => '<div class="heading"><h2>',
			'after_title'   => '</h2></div><div class="content">'
		
		));
	}
add_action('widgets_init','zboom_right_sidebar');


function zboom_footer_widget(){
	register_sidebar(array(
		'id' 	=> 'footer-widget',
		'name'  => 'zBoom Theme Footer Widgets',
		'description' => 'You can add several options in your footer.',
		'before_widget' => '<div class="col-1-4"><div class="wrap-col"><div class="box">',
		'after_widget'  => '</div></div></div></div>',
		'before_title'  => '<div class="heading"><h2>',
		'after_title'   => '</h2></div><div class="content">'
	
	));
}
add_action('widgets_init','zboom_footer_widget');




	function contact_sidebar(){
		register_sidebar(array(
			'id'	=> 'contact-sidebar',
			'name' 	=> 'Contact Page Sidebar',
			'description' => 'Add Your Location Map and contact details',
			'before_widget' => '<div class="wrap-col"><div class="box">',
			'after_widget'  => '</div></div></div>',
			'before_title'  => '<div class="heading"><h2>',
			'after_title'   => '</h2></div><div class="content">'
	));
}
add_action('widgets_init','contact_sidebar');

require_once ('redux/ReduxCore/framework.php');
require_once ('redux/sample/config.php');

function zboom_font_awesome(){
	wp_register_style('font-awesome',get_template_directory_uri().'/css/font-awesome.min.css');
	wp_enqueue_style('font-awesome');
} 
add_action('wp_enqueue_scripts','zboom_font_awesome');
add_action('admin_enqueue_scripts','zboom_font_awesome');









?>